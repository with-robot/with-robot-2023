using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class basic : MonoBehaviour
{
    // Start is called before the first frame update

    Vector3 dir = Vector3.zero;
    public float moveSpeed = 50.0f;

    void Start()
    {


    }

    // Update is called once per frame
    void Update()
    {
        //GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        //sphere.transform.position = new Vector3(0, 10, 0);
        //sphere.AddComponent<Rigidbody>();

        this.transform.position += dir* moveSpeed * Time.deltaTime;
    }

    public void forward()
    {
        Debug.Log("forward");
        dir = this.transform.forward;
    }

    public void stop()
    {
        dir = Vector3.zero;
    }

    public void left()
    {
        dir =  -this.transform.right;
    }

    public void right()
    {
        dir = this.transform.right;
    }

    public void back()
    {
        dir = -this.transform.forward;
    }


}
